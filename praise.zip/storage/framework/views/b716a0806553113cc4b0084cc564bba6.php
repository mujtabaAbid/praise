<div class="footer">
    <div class="copyright">
        <p>2024 © Beauty Connect.</p>
    </div>
</div>
<?php /**PATH E:\laragon\www\praise\resources\views/includes/footer.blade.php ENDPATH**/ ?>