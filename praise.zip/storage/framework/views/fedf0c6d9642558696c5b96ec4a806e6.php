<?php $__env->startSection('title', 'Praisy | Dashboard'); ?>
<?php $__env->startSection('content'); ?>
   <div class="row">
    <h1 class="mt-5 pt-5 text-center">welcome praisy</h1>
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\praise\resources\views/index.blade.php ENDPATH**/ ?>