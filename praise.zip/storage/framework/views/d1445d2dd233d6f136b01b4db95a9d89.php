<!-- All StyleSheet -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
<!-- Datatable -->
<link href="<?php echo e(asset('assets/vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
<!-- Add Tagify CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css">
<!-- Globle CSS -->
<link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
<?php /**PATH E:\laragon\www\praise\resources\views/includes/style.blade.php ENDPATH**/ ?>