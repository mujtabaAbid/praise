(function($) {
    "use strict"
    
    new dlabSettings({
        sidebarStyle: "compact"
    });


})(jQuery);