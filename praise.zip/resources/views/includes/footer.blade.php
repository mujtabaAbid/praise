<div class="footer">
    <div class="copyright">
        <p>2024 © Beauty Connect.</p>
    </div>
</div>
