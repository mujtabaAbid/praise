@extends('layout.app')
@section('title', 'Praisy | Dashboard')
@section('content')
   <div class="row">
    <h1 class="mt-5 pt-5 text-center">welcome praisy</h1>
   </div>
@endsection

@section('custom-script')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script></script>
@endsection
